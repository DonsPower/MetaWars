<?php
$conexion=mysqli_connect('localhost','root','','juego_cartas') or die ('Error al conectar con la base de datos');
?>
