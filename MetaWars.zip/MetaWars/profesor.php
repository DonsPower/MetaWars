
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">

    <title>Registro Profesores | MetaWars</title>
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/boton.css">
  </head>
  <body>
    <header>
      <div class="contenedor">
        <div id="marca">
          <h1><span class="resaltado">MetaWars</span> Rutas  Metabólicos</h1>
        </div>
        <nav>
          <ul>
            <li><a href="index.php">Inicio</a></li>
            <li><a href="src/registroLogin.php">Jugar</a></li>
            <li class="actual"><a href="profesor.php">¿Eres un profesor?</a></li>
             <li><a href="manual.html">Manual</a></li>
          </ul>
        </nav>
      </div>
    </header>

    <section id="boletin">
      <div class="contenedor">
        <h1>Introduce la clave de acceso para iniciar sesión:</h1>
        <form>
          <input type="email" placeholder="Ingrese la clave...">
          <button type="submit" class="boton1">Iniciar</button>
        </form>
      </div>
    </section>

    <section id="main">
      <div class="contenedor">
       
        <br/><br/>
        <article id="main-col">
          <ul id="servicios">
            <li>
              <h3>Información</h3>
              <p>En esta sección se puede observar los resultados iniciales y finales de todos los alumnos, al igual que la gestión de grupos de los mismos alumnos para su registro.</p>
            </li>

          </ul>
        </article>

        <aside id="lateral">
          <div class="oscuro">
            <h3>-Clave-</h3>
            <p>La clave ya está definida y únicamente el Profesor debe de introducirla.</p>

          </div>
        </aside>
      </div>
    </section>
    <footer>
      <p>DonsInc, Copyright &copy; 2018</p>
    </footer>
  </body>
</html>
