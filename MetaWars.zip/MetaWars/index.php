<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">

    <title>MetaWars | Bienvenidos</title>
    <link rel="stylesheet" href="css/estilos.css">
  </head>
  <body>
    <header>
      <div class="contenedor">
        <div id="marca">
          <h1><span class="resaltado">MetaWars</span> Rutas Metabólicos</h1>
        </div>
        <nav>
          <ul>
            <li class="actual"><a href="index.php">Inicio</a></li>
            <li><a href="src/registroLogin.php">Jugar</a></li>
            <li><a href="profesor.php">¿Eres un profesor?</a></li>
            <li><a href="manual.html">Manual</a></li>
          </ul>
        </nav>
      </div>
    </header>

    <section id="cabecera">
      <div class="contenedor"></div>
    </section>

    <section id="boletin">
      <div class="contenedor">

      </div>
    </section>

    <section id="cajas">
      <div class="contenedor">
        <div class="caja">
          <img src="./img/Meta.png">
          <h3>¿Qué es?</h3>
          <p id=des>MetaWars es un Juego de Cartas Coleccionables estratégico con el objetivo de que sea utilizado como herramienta auxiliar en el entendimiento de rutas
metabólicas de acuerdo al estilo de aprendizaje de los alumnos.</p>
        </div>
        <div class="caja">
          <img src="./img/logo1.png">
          <h3>Guerrero.</h3>
          <p>Es el personaje encargado atacar haciendo daño a la célula enemiga.</p>
        </div>
        <div class="caja">
          <img src="./img/esccudo.png">
          <h3>Defensor.</h3>
          <p>Es el personaje encargado de defender a los guerreros.</p>
        </div>
      </div>
    </section>

    <footer>
      <p>Dons. Inc, Copyright &copy; 2018</p>
    </footer>
  </body>
</html>
